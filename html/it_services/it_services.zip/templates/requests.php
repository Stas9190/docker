<!-- Page Title -->
<div class="section section-breadcrumbs">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h1>Мои заявки</h1>
            </div>
        </div>
    </div>
</div>

<div class="section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <!-- форма создания новой заявки -->
                <?php if (isset($context['services'])) : ?>
                    <?php $approximate_price = 0; ?>
                    <?php for ($i = 0; $i < count($context['services']); $i++) : ?>
                        <?php for ($j = 0; $j < count($context['services'][$i]['data']); $j++) : ?>
                            <dl class="uk-description-list uk-description-list-divider">
                                <dt>Название: <?= $context['services'][$i]['data'][$j]['name'] ?></dt>
                                <dt>Тип: <?= $context['services'][$i]['data'][$j]['s_type'] ?></dt>
                                <dt>Цена: <?= $context['services'][$i]['data'][$j]['price'] ?></dt>
                                <?php $approximate_price += $context['services'][$i]['data'][$j]['price']; ?>
                            <?php endfor; ?>
                        <?php endfor; ?>
                        <dt>Приблизительная цена: <?= number_format($approximate_price, 2, '.', '') ?>₽</dt>
                            </dl>
                            <form method="POST" role="form">
                                <input type="hidden" name="method" value="create_new_request">
                                <input type="hidden" name="approximate_price" value="<?= $approximate_price ?>">
                                <div class="uk-margin">
                                    <input class="uk-input" type="text" name="comment" id="comment" style="width: 40%;" placeholder="Комментарий">
                                </div>
                                <div class="uk-margin">
                                    <button type="submit" class="uk-button uk-button-primary">Создать</button>
                                </div>
                            </form>
                        <?php endif; ?>

                        <br><br>

                        <div id="table-area" class="uk-overflow-auto">
                            <table id="requests" class="uk-table uk-table-striped uk-table-hover" style="width:100%">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Дата заявки</th>
                                        <th>Комментарий</th>
                                        <th>Приблизительная цена</th>
                                        <th>Статус заявки</th>
                                        <th>ФИО</th>
                                        <th>Почта</th>
                                        <th>Логин</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (isset($context['main']['data'])) : ?>
                                        <?php for ($i = 0; $i < count($context['main']['data']); $i++) : ?>
                                            <tr>
                                                <td><?= $i + 1 ?></td>
                                                <td><?= $context['main']['data'][$i]['request_date'] ?></td>
                                                <td><?= $context['main']['data'][$i]['comment'] ?></td>
                                                <td><?= $context['main']['data'][$i]['approximate_price'] ?></td>
                                                <td><?= $context['main']['data'][$i]['status'] ?></td>
                                                <td>
                                                    <?php
                                                            echo isset($context['main']['data'][$i]['fio']) ? $context['main']['data'][$i]['fio'] : $_SESSION['sid'][0][0]['fio'];
                                                            ?>
                                                </td>
                                                <td>
                                                <?php
                                                            echo isset($context['main']['data'][$i]['mail']) ? $context['main']['data'][$i]['mail'] : $_SESSION['sid'][0][0]['mail'];
                                                            ?>
                                                </td>
                                                <td>
                                                <?php
                                                            echo isset($context['main']['data'][$i]['login']) ? $context['main']['data'][$i]['login'] : $_SESSION['sid'][0][0]['login'];
                                                            ?>
                                                </td>
                                                <td>
                                                    <a href="http://localhost/it_services/index.php/delete_request/<?= $context['main']['data'][$i]['id'] ?>" uk-icon="icon: trash"></a>
                                                </td>
                                            </tr>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th>#</th>
                                        <th>Дата заявки</th>
                                        <th>Комментарий</th>
                                        <th>Приблизительная цена</th>
                                        <th>Статус заявки</th>
                                        <th>ФИО</th>
                                        <th>Почта</th>
                                        <th>Логин</th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>

                            <p uk-margin>
                                <a class="uk-button uk-button-secondary" href="http://localhost/it_services/index.php/lk">Назад</a>
                            </p>
                        </div>
            </div>
        </div>
    </div>
</div>