<?php
$DATABASES = [
    "MySql" => [
        "NAME" => "it_services",
        "HOST" => "localhost",
        "USER" => "root",
        "PASSWORD" => "",
        "CHARSET" => "SET NAMES utf8",
        "DRIVER" => "mysql"
    ]
];

$BASE_FILE = 'base.php';
