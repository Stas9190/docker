<!-- Пользователь не найден -->
<div class="error-page">
    <div class="error-content">
        <h4><i class="fa fa-warning text-red"></i> Авторизуйтесь, чтобы получить доступ!</h4>
            <p>
                <a href="?act=login">Авторизоваться</a>
            </p>
    </div>
</div>