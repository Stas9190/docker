<!-- Пользователь не найден -->
<div class="error-page">
    <div class="error-content">
        <h4><i class="fa fa-warning text-red"></i> Пользователь с таким именем не найден!</h4>
            <p>
                <a href="?act=register">Перейдите на страницу регистрации</a>
            </p>
    </div>
</div>